<div class="card container m-3 p-3">
    <h1>Címlap</h1>
    <div class="flex gap-2">
        <a href="/termekek">
            <button class="btn btn-primary">
                Tovább a terméklistára
            </button>
        </a>
        <a href="/felhasznalok">
            <button class="btn btn-primary">
                Tovább a felhasználó listára
            </button>
        </a>
    </div>
</div>