<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="card container p-3 m-3">
        <?php if ($isSucces) : ?>
            <div class="alert alert-success">
                Termék létrehozása sikeres
            </div>
        <?php endif ?>
        <form action="/termekek" method="post">
            <input type="text" name="name" placeholder="Név..."> <br>
            <input type="number" name="price" placeholder="Ár..."> <br>
            <input type="submit" name="submit" class="btn btn-success" value="Küldés">
        </form>
        <?php foreach ($products as $product) : ?>
            <h3>Név: <?= $product["name"] ?></h3>
            <p>Ár: <?= $product["price"] ?> Ft</p>
            <hr>
        <?php endforeach ?>
    </div>
</body>
</html>