<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="card container m-3 p-3">
        <h1>Címlap</h1>
        <a href="/termekek">
            <button class="btn btn-primary">
                Tovább a terméklistára
            </button>
        </a>
    </div>
</body>
</html>