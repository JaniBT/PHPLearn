<div class="card container m-3 p-3">
    <h1>Címlap</h1>
    <a href="/termekek">
        <button class="btn btn-primary">
            Tovább a terméklistára
        </button>
    </a>
</div>